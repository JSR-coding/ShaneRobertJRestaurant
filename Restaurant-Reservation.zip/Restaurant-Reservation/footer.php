<!--footer-->
<footer class="footer" id="footer">
 <div class="container"><br>
  <div class="row">
    <div class="col-sm-12 text-center">
      <div class="social-icon">
        <a href="index.php"><i class="fa fa-facebook"></i></a>
        <a href="index.php"><i class="Paradox Restaurant</b></p>
        <p><i class="fa fa-phone"></i> &nbsp;<i class="fa fa-envelope-o"></i></p>
      </div>
    </div>
  </div>
 </div>
</footer>
<!--end of footer-->
</body>
<!---end of body-->
</html>